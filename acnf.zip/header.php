<link href="mainstylesheet.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css">
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.0.0/jquery.min.js"></script>
<script src="js/appEngine.js"></script>
<script language="javascript">
<!-- hide from old browsers
slidemage1= new Image(946,218); 
slidemage1.src="slideimages/bnr2.jpg"; 
slidemage2= new Image(946,218); 
slidemage2.src="slideimages/bnr3.jpg"; 																																																																																															
slidemage3= new Image(946,218); 
slidemage3.src="slideimages/bnr4.jpg"; 
trade01 = new Image(231,114);
trade01.src = "images/trade01.png";
trade02 = new Image(231,114);
trade02.src = "images/trade02.png";
trade03 = new Image(231,114);
trade03.src = "images/trade03.png";
trade04.src = new Image(231,114);
trade04.src = "images/trade04.png";
presenters = new Image(456,166);
presenters.scr = "images/presenters.jpg";
africef = new Image(663,179);
africef.src = "images/africef_2016.png";

//-->
</script>


<body>
<table width="946" border="0" align="center" cellpadding="2px">
 <tr>
    <td height="80"><img src="images/logo3_120.png" alt="logo" align="left"><div style="margin-top:30px;font-family:cambria;color:#069;font-size:26px;font-weight:bold;">African Caribbean Network Foundation</div><div></div><span style="color:#E36C0A;font-weight:bold;"><em>...Bridging the African-Caribbean Gap</em></span><div></td>
    <td align="right" valign="top" class="headerright"><font size="1"><a style="text-decoration:none;color:#000000;" href="index.php">HOME</a> | <a style="text-decoration:none;color:#000000;" href="http://www.acnfoundation.org/webmail">WEBMAIL</a> | <a style="text-decoration:none;color:#000000;" href="contact.php">CONTACT US</a></font><br>
      <br></td>
  </tr>
  <tr>
    <td colspan="2" align="center" style="font-family:Arial, Helvetica, sans-serif;font-size:15px;padding:0px;"><ul id="MenuBar1" class="MenuBarHorizontal">
      <li class="navsideseparator"><a href="index.php">Home</a>        </li>
      <li class="navsideseparator"><a href="aboutus.php" class="MenuBarItemSubmenu">About ACNF</a>
        <ul>
        <li  class="navbottomseparator"><a href="aboutus.php#foundation">The Foundation</a></li>
          <li  class="navbottomseparator"><a href="aboutus.php#vision">Vision</a></li>
          <li class="navbottomseparator"><a href="aboutus.php#mission">Mission</a></li>
          <li class="navbottomseparator"><a href="aboutus.php#corevalues">Core Values</a></li>         
        </ul>
      </li>
      <li class="navsideseparator"><a href="management.php">Management</a></li>
      <li class="navsideseparator"><a href="programmes.php">Programmes&nbsp;&nbsp;</a>
  <li class="navsideseparator"><a href="events.php">Events</a></li>
      <li class="navsideseparator"><a href="#">Media </a></li>
      <li><a href="contact.php">Contact Us</a></li>
    </ul></td>
  </tr>
</table>
<script type="text/javascript">
var MenuBar1 = new Spry.Widget.MenuBar("MenuBar1", {imgDown:"SpryAssets/SpryMenuBarDownHover.gif", imgRight:"SpryAssets/SpryMenuBarRightHover.gif"});
</script>