// JavaScript Document
$(document).ready()
{
			
	$("#panelheader1").click(function(){
        alert("me");
	});
}