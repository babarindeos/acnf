<link href="mainstylesheet.css" rel="stylesheet" type="text/css" />
<body>
<table width="946" border="0">
  <tr>
    <td width="663" valign="top" style="font-family:corbel;font-size:14px;padding:5px;border-right:1px solid #f1f1f1;">

<br><p><span style="font-weight:bold;font-size:25px;color:#E36C0A;">CURRENT EVENT</span><br>
<ul>
<li><a href = "africef.php" title = "African-Caribbean Economic Forum (AFRICEF)"><span style="font-family:'Trebuchet MS', Arial, Helvetica, sans-serif;font-size:14px;color:#069;">African-Caribbean Economic Forum (AfriCef)</span></a></li>

</ul>

 <hr size="1px" color='#e1e1e1'>
 <br>
 
     
    <span style="font-weight:bold;font-size:25px;color:#E36C0A;;">PAST EVENTS</span><br>
 
 <ul>
      <li><a href = "tinex_expo2014.php" title = "Trade & Invest Nigeria Expo (TINEX)"><span style="font-family:'Trebuchet MS', Arial, Helvetica, sans-serif;font-size:14px;color:#069;">TRADE &amp; INVEST NIGERIA EXPO (TINEX)</span></a></li>

<li><a href = "african_music_seminar_2000.php" title = "Trade & Invest Nigeria Expo (TINEX)"><span style="font-family:'Trebuchet MS', Arial, Helvetica, sans-serif;font-size:14px;color:#069;">African Music Seminar 2000</span></a></li> 

<li><a href = "africa_raffle_draw_promotion.php" title = "Trade & Invest Nigeria Expo (TINEX)"><span style="font-family:'Trebuchet MS', Arial, Helvetica, sans-serif;font-size:14px;color:#069;">1st Africa Raffle Draw Promotion</span></a></li>



    
      
      
      
</ul>      
 

  
  
  
  
  
 </p></td>
    <td width="267" valign="top"  style="font-family:corbel;font-size:14px;"><div align="right"><img src="images/facebooktwitter.png" width="80" height="43" alt="socialmedia"></div>
    <br>
  <table width="100%" cellpadding="3px" cellspacing="0px" style="border-left:1px solid #FFA477;border-bottom:1px solid #FFA477;border-right:1px solid #FFA477;"><tr><td width="1%" style="background-color:#B22106;border-bottom:1px solid #B22106;"></td>
  <td style="background-color:#FFA477;color:white;border-bottom:1px solid #B22106;font-weight:bold;border-right:1px solid #FFA477;">TINEX Quick Lines</td><tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#overview">Overview</a></td></tr>
  <tr>
    <td colspan="2" class="smallboxstyle" ><a href="tinex_expo2014.php#description">Description</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#coreobjectives">Core Objectives</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#island">Host Island</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#expodirector">Expo Director</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#highlights">Highlights</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#seminar">Seminar</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#forums">Interactive Forums</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#targetmarket">Target Audience &amp; Market</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#caribbeanisland">Caribbean Island Participation</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#forwhom">For Whom</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#focussector">Focus Sectors</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#whyparticipate">Why Participate in TINEX</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#impact">Impact</a></td>
  </tr>
  </table>
    
  <p><br>
    </p>
  <p><br>
  </p></td>
  </tr>
</table>
</body>
