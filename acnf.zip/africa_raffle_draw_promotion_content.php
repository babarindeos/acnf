<link href="mainstylesheet.css" rel="stylesheet" type="text/css" />
<body>
<table width="946" border="0">
  <tr>
    <td width="663" style="font-family:corbel;font-size:14px;padding:5px;border-right:1px solid #f1f1f1;" valign="top">
    <p><br>
    <a name="1st Africa Raffle Draw
Promotion"></a>

 <span style="font-family:'Trebuchet MS', Arial, Helvetica, sans-serif;font-size:20px;color:#069;font-weight:bold;">1st Africa Raffle Draw Promotion</span><br><br>
    
    <div>
<img src="images/ardp.jpg" alt="Ambassador
Justin Duru" align="left" hspace="4px">
<strong>President General-in-Council: Ambassador
Justin Duru</strong> during the ‘1st Africa Raffle Draw
Promotion’ held at the <strong>St. Maarten Jubilee
Library</strong> in Philipsburg: 1996

</div>

<div style="clear:both;"><br>
<ol>
 <li>Caribbean Youths Cultural & Educational 
     Tour to Nigeria, Ghana and Togo in 1997 </li>
 <li>Sunrise Africa TV Programs: Promoting 
    African Movies & Cultural Heritage in the
   Caribbean 
</li>
<li>African Gala Festival 1997 & 1998 held in the St. Maarten</li>
<li>Lunching of Dr. Bamidele’s Book “The Pull of Blood” in celebration of Black History Month in Barbados, 2000</li>
<li>African Raffle Draw Event in St. Maarten, St. Martin, Saba, St. Eustatius & Anguilla: 1996 - 1997</li>
<li>Co-Production of the Movie on “Busa – Barbados National Hero", in association with the Barbados Commission for Pan-African Affairs (PANCOM): 2000 </li>
<li>Co-Production of Ola Rotimi’s “The Gods Are Not to Blame” Stage Play in Barbados Community College: 2000</li>
<li>African Heritage Radio Magazine Series – GBBC 99.9FM </li>
<li>Ogene Africa Radio Magazine Series – Soualiga Radio 99.9Choice FM </li>
<li>Syndicated Broadcast of African Movies on LBC TV Channel 7 SXM, 3SCS-TV Saba, St. Martin Cable TV, 
       WTJX Channel 12 (Virgin Islands Public Television Systems) – St. Thomas and several other Caribbean Islands 
</li>
<li>Promotion of ‘Trade & Invest Nigeria Expo (TINEX)’ in the Caribbean: 2014</li>
<li>Coordinating invited Caribbean Leaders & Net-Worth Personalities attendance of Nigeria’s Transition to 
       Democracy and Presidential Inauguration in 1999 
</li>
<li>Member of ‘COJA All African Games 2003 – Travel & Tour Committee’ 
</li>
<li>Introduction of ‘Indigenous African Products’ into the Caribbean Market</li>
<li>Promoting the development of ‘Direct Flight Services’ to the Caribbean in collaboration with Calypso Tours (West Africa) Ltd, Earth & Knight Airlines, with destinations as Curacao, St. Maarten and Barbados</li>
</ol> 
</div>






<div align="right"><a href="#top">Top</a></div>
<a name="bottom"></a>
<br><br>
 
 
 
 
 
 
 </td>
    <td width="267" valign="top"  style="font-family:corbel;font-size:14px;"><div align="right"><img src="images/facebooktwitter.png" width="80" height="43" alt="socialmedia"></div>
    <br>
  <table width="100%" cellpadding="3px" cellspacing="0px" style="border-left:1px solid #FFA477;border-bottom:1px solid #FFA477;border-right:1px solid #FFA477;"><tr><td width="1%" style="background-color:#B22106;border-bottom:1px solid #B22106;"></td>
  <td style="background-color:#FFA477;color:white;border-bottom:1px solid #B22106;font-weight:bold;border-right:1px solid #FFA477;">Event Quick Lines</td><tr>
    <td colspan="2" class="smallboxstyle"><a href="events.php">Current Events</a></td></tr>
  <tr>
    <td colspan="2" class="smallboxstyle" ><a href="events.php">Past Events</a></td>
  </tr>
</table>
    
  <p><br>
    </p>
  <p><br>
  </p></td>
  </tr>
</table>
</body>
