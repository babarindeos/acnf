<link href="mainstylesheet.css" rel="stylesheet" type="text/css" />
<body>
<table width="946" border="0">
  <tr>
    <td width="663" valign="top" style="font-family:corbel;font-size:14px;padding:5px;border-right:1px solid #f1f1f1;"><p><span style="font-size:18px;font-weight:bold;color:#069"><a name="profiles"></a>Executive Profiles</span></p>
<p>
<table width="100%" cellspacing="0px" cellpadding="5px">    
<tr>
<td style="border-bottom:1px solid #e1e1e1;">    
    <a name="president"></a>
    <img name="" src="profiles/justin.gif" width="94" height="110" alt="">
      

</td>
<td valign="top" style="border-bottom:1px solid #e1e1e1;">
  <p><strong>ACNF President General-in-Council</strong><br>
    <br>
Ambassador Duru Justin V. C., a Nigerian Seasoned Theatre Artiste, Radio ersonality, Television Producer, Business Development Consultant, Project Manager, Events Promoter, Human Resource and International Relations Professional, with commendations from various African and Caribbean Leaders. </p></td></tr>
<tr>
  <td style="border-bottom:1px solid #e1e1e1;"><a name="vice-president"></a><img src="profiles/joslyn.gif" width="94" height="110"></td>
  <td valign="top" style="border-bottom:1px solid #e1e1e1;"><strong>ACNF Vice President</strong></p>
    <p>Ms. Joslyn L. Courtar, a citizen of St. Eustatius, Dutch Caribbean. She was a Head Controller 
      for the Federal Government of the Netherlands Antilles and subsequently, a Labour Inspector for the St. Maarten Government <br>
    </td>
</tr>
<tr>
  <td style="border-bottom:1px solid #e1e1e1;"><a name="secretary"></a><img src="profiles/fowler.gif" width="94" height="110"></td>
  <td valign="top" style="border-bottom:1px solid #e1e1e1;"><strong>ACNF Secretary General</strong></p>
    <p>Ms. Cheryl I. Fowler, a citizen of Curaçao, Dutch Caribbean and Professional Public Administrator 
    <p></p></td>
</tr>
</table>
  <p>
  
 </p></td>
    <td width="267" valign="top"  style="font-family:corbel;font-size:14px;"><div align="right"><img src="images/facebooktwitter.png" width="80" height="43" alt="socialmedia"></div>
    <br>
  <table width="100%" cellpadding="3px" cellspacing="0px" style="border-left:1px solid #FFA477;border-bottom:1px solid #FFA477;border-right:1px solid #FFA477;"><tr><td width="1%" style="background-color:#B22106;border-bottom:1px solid #B22106;"></td>
  <td style="background-color:#FFA477;color:white;border-bottom:1px solid #B22106;font-weight:bold;border-right:1px solid #FFA477;">TINEX Quick Lines</td><tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#overview">Overview</a></td></tr>
  <tr>
    <td colspan="2" class="smallboxstyle" ><a href="tinex_expo2014.php#description">Description</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#coreobjectives">Core Objectives</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#island">Host Island</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#expodirector">Expo Director</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#highlights">Highlights</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#seminar">Seminar</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#forums">Interactive Forums</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#targetmarket">Target Audience &amp; Market</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#caribbeanisland">Caribbean Island Participation</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#forwhom">For Whom</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#focussector">Focus Sectors</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#whyparticipate">Why Participate in TINEX</a></td>
  </tr>
  <tr>
    <td colspan="2" class="smallboxstyle"><a href="tinex_expo2014.php#impact">Impact</a></td>
  </tr>
  </table>
    
  <p><br>
    </p>
  <p><br>
  </p></td>
  </tr>
</table>
</body>
