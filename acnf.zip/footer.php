<body>
<table width="946" border="0" align="center" cellpadding="6px" style="font-family:corbel,helvetica;font-size:13px;background-color:#069;color:white;">
 <tr><td align="right">
 &copy;2013-2017 African Caribbean Network Foundation (ACNF). All rights reserved.
 
 </td></tr></table>
</body>
