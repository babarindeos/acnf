<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="mainstylesheet.css" rel="stylesheet" type="text/css" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="Information about ACNF - History,Foundation,Vision,Mission,Core Values, Organizational Structure,Management, Advisory Council/Patrons, Regional/Country Chapter Executives" />
<meta name="keywords" content="About ACNF,ACNF,Africa,Caribbean" />

<title>African Caribbean Network Foundation(ACNF) - About ACNF</title>

<style type="text/css">
body {
	margin-top: 0px;
}
</style>
</head>

<body onload="slide();" bgcolor="#999999">
<table width="948" border="0" align="center" bgcolor="#FFFFFF" cellpadding="1px">
  <tr>
    <td>
    <?php
	 include("header.php");
	
	?>
    
    </td>
  </tr>
  <tr><td>
  <?php
  /*
  include("imageslider.php");
  include("tradeinvestmentbar.php"); */
  ?>
  
  </td></tr>
  <tr><td>
  <?php
  include("aboutus_content.php");
  
  ?>
  
  </td></tr>
  <tr><td>
  <?php
  
  include("footer.php");
  ?>
  </td></tr>
</table>
</body>
</html>