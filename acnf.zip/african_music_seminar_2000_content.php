<link href="mainstylesheet.css" rel="stylesheet" type="text/css" />
<body>
<table width="946" border="0">
  <tr>
    <td width="663" style="font-family:corbel;font-size:14px;padding:5px;border-right:1px solid #f1f1f1;" valign="top">
    <p><br>
    <a name="African Musica Seminar 2000"></a>
    
    <span style="font-family:'Trebuchet MS', Arial, Helvetica, sans-serif;font-size:20px;color:#069;font-weight:bold;">African Music Seminar 2000</span><br><br>
  
Ms. Patience of ‘The Nations Newspaper’ Barbados, and Ms. Gabriella Moenig (Special Guest Speaker from Germany) during the ‘African Music Seminar 2000’ organized by African Caribbean Network Foundation (ACNF) and Commission for Pan-African Affairs (PANCOM) – Barbados, at the ‘Clement Payne Center’ in Barbados 
<img src="images/ms_patience.jpg" alt="" align="top" vspace="5px" >
<img src="images/african_music_seminar.jpg" alt="African Music Seminar" width="200px">
<p>









<div align="right"><a href="#top">Top</a></div>
<a name="bottom"></a>
<br><br>
 
 
 
 
 
 
 </td>
    <td width="267" valign="top"  style="font-family:corbel;font-size:14px;"><div align="right"><img src="images/facebooktwitter.png" width="80" height="43" alt="socialmedia"></div>
    <br>
  <table width="100%" cellpadding="3px" cellspacing="0px" style="border-left:1px solid #FFA477;border-bottom:1px solid #FFA477;border-right:1px solid #FFA477;"><tr><td width="1%" style="background-color:#B22106;border-bottom:1px solid #B22106;"></td>
  <td style="background-color:#FFA477;color:white;border-bottom:1px solid #B22106;font-weight:bold;border-right:1px solid #FFA477;">Event Quick Lines</td><tr>
    <td colspan="2" class="smallboxstyle"><a href="events.php">Current Events</a></td></tr>
  <tr>
    <td colspan="2" class="smallboxstyle" ><a href="events.php">Past Events</a></td>
  </tr>
</table>
    
  <p><br>
    </p>
  <p><br>
  </p></td>
  </tr>
</table>
</body>
