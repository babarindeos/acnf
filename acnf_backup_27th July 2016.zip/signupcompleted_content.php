<font color='green'><strong>A message has to been sent to your email to activate your account. Thank you for registering with us.</strong></font><br><br><br><br>				   
			
			