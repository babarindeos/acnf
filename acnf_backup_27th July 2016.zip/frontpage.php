<body>
<table width="946" border="0">
  <tr>
    <td width="663" style="font-family:corbel;font-size:14px;padding:5px;border-right:1px solid #f1f1f1;"><p><span style="font-size:18px;font-weight:bold;color:#069">Welcome to African Caribbean Network Foundation (ACNF)</span></p>
    <div style="text-align:center">
      <img src="images/presenters.jpg">
    
    </div>
    <img name="africef" src="images/africef_2016.png" width="663" height="179" alt="">
     
    <div align='center' style="font-size:20px;margin-top:-40px;"><blockquote>
    Afrique - Caraïbes Forum Économique
África, <br>
el Caribe Foro Económico </div>
<div>
<div style='font-weight:bold;font-size:20px;background-color:#09C;color:white;'> &nbsp;Presentations...</div>
<div style="margin-bottom:5px;margin-top:5px;">
  <em>AFRICEF Speakers and Panelists comprise distinguished African, Caribbean and Latin American Leaders, Ministers, Net-Worth Personalities, Policy and Decision Makers among which include: </em></div>
<div>
  <div><img src="images/buhari.jpg"><img src="images/patterson.jpg"><img src="images/stuart.jpg"><img src="images/olusegun.jpg"><img src="images/perry.jpg"></div>
  <div style="text-align:center">
  <img src="images/mahama.jpg"><img src="images/owen.jpg"><img src="images/uhuru.jpg">
  
  </div>
 <div style="border-radius:6px;background-color:#09C;color:#ffffff;padding:3px;">
 President Muhammadu Buhari GCFR of Nigeria (Host), Rt. Hon. Percival Patterson QC JP (Former Jamaican Prime Minister), 
Rt. Hon. Freundel Stuart QC – Prime Minister of Barbados), Chief Olusegun Obasanjo GCFR (Former Nigerian President), 
Rt. Hon. Perry Christie – Prime Minister of The Bahamas, President John Mahama of Ghana, 
Sir Owens Arthur (Former Barbados Prime Minister) and President Uhuru Kenyatta of Kenya 

 </div>

  <p><strong>AFRICEF</strong> is a 3 days fora initiated by <strong>ACNF</strong> as a veritable platform to explore ways of developing and promoting bilateral and multilateral economic, investment, trade and tourism relations between Africa and the Caribbean.
 <em><strong>AFRICEF</strong> is being hosted in Nigeria, in partnership with the:</em>
  <ul>
    <li>Nigerian Investment Promotion  Commission (NIPC) </li>
    <li>Federal Ministry of Industry,  Trade &amp; Investment (FMITI) </li>
    <li>Federal Ministry of Foreign  Affairs (FMFA) </li>
    <li>Nigerian Export Promotion Council  (NEPC) </li>
    <li>Nigerian Television Authority  (NTA) </li>
    <li>Raw Materials Research &amp;  Development Council (RMRDC)</li>
    <li>Abuja Investment Company Ltd  (AIC) </li>
<li>Manufacturers Association of Nigeria (MAN) </li>
<li>National Association of Chambers of Commerce,  Industry, Mines &amp; Agriculture (NACCIMA)</li>
<li>Small &amp; Medium Enterprises  Development Agency of Nigeria (SMEDAN)</li>
<li>Nigerian Export-Import Bank  (NEXIM) </li>
<li>Bank of Industry (BOI) </li>
  </ul>
  
</div>  
<div>
<em><strong>AFRICEF</strong> will in addition to the main presentations feature:</em>
<ul style="margin-top:1px;">
 <li>Panel Plenary Sessions</li>
 <li>Products & Services Exhibition</li>
 <li>G2G, G2B, B2B Breakaway-Networking Sessions
</ul>

<p>
<em><strong>AFRICEF</strong> is primarily targeted at:</em>
<ul style="margin-top:-13px;">
  <li>Forming socio-cultural ties & synergies anchored on shared history, heritage & affinity. </li>
  <li>Developing lasting agricultural, industrial, investment, tourism & trade relations. </li>
  <li>Establishing customized financial services to enhance the development & promotion of agricultural, industrial, investment, tourism & trade relations. </li>
  <li>Promoting the establishment of Direct Air & Sea Transport Services between both regions. </li>
  <li>Drumming-up support for Afro-Caribbean Relations, Unity & Peace through tourism, trade and socio-economic exchange programs.</li>
</ul>

</div>
<br><br>
<hr size='1px'>
<div style="color:#09C;font-weight:bold;font-size:18px;">
Replace Testimonials with Partners and Adverts</div>
<blockquote>
 <em>I commend the African Caribbean Network Foundation (ACNF) goals of bridging the African-Caribbean Gap through the promotion of bilateral and multilateral cultural and socio-economic relationship between both regions..!</em> <strong>Rt. Hon. Percival J. Patterson QC, MP – Former Prime Minister of Jamaica</strong> </blockquote>
 
 <blockquote>
 <em>I have no doubt that the African Caribbean Network Foundation (ACNF) through its noble objectives will have a great impact, as it seeks to strengthen bonds between Africa and the Caribbean...!</em> <strong>Rt. Hon. Owen S. Arthur – Former Prime Minister of Barbados</strong>
 </blockquote>
 
 <blockquote>
 <em>I congratulate the African Caribbean Network Foundation (ACNF) for your good works, and urge you to continue projecting Africa’s cultural heritage to the rest of the world...! </em><strong>Rtd. Gen. Abdulsalami Abubakar – Former Head of State of Nigeria</strong>
 </blockquote>

<blockquote>
<em>The African Caribbean Network Foundation (ACNF) objectives aimed at promoting bilateral and multilateral relations between both regions must be commended, encouraged, and fully supported by all African Countries and Caribbean Islands...! </em><strong>Hon. Elton Jones – Former Commissioner of Culture & Youth Affairs, Government of St. Maarten, Dutch Caribbean</strong>

</blockquote>

    <br><br><br><br>    
    <p><br>
    <table width="100%" cellpadding="0px" cellspacing="7px"><tr><td valign="top">
 
 <table width="100%" cellpadding="3px" cellspacing="0px"><tr><td width="1%" style="background-color:#B22106;border-bottom:1px solid #B22106;"></td>
 <td style="color:#069;border-bottom:1px solid #B22106;font-weight:bold;">ACNF Programmes</td><tr><tr>
   <td colspan="2" style="font-size:14px;padding:5px;">
  
<ul style="margin-top:2px;margin-left:-15px;">
<li><a href="programmesimp.php#tep">Transnational Exchange Programme (TEP)</a></li>
<li><a href="programmesimp.php#tinex">Trade &amp; Invest Nigeria Expo (TINEX)</a></li>
<li><a href="programmesimp.php#sunrise">Sunrise Africa Television (SAT)</a></li>
<li><a href="programmesimp.php#womencon">Afro-Caribbean Women Conference (AWC)</a></li>
<li><a href="programmesimp.php#youthcon">Afro-Caribbean Youth Conference</a></li>
<li><a href="programmes.php#skill">Afro-Caribbean Entrepreneurial &amp; Skill Acquisition Program (AFRESAP)</a></li>
</ul>
</td></tr></table>
 
 </td><td width="50%">
 
 <table width="100%" cellpadding="3px" cellspacing="0px"><tr><td width="1%" style="background-color:#B22106;border-bottom:1px solid #B22106;"></td>
 <td style="color:#069;border-bottom:1px solid #B22106;font-weight:bold;">ACNF Programmes</td><tr><tr>
   <td colspan="2" style="font-size:14px;padding:5px;">
  
<ul style="margin-top:2px;margin-left:-15px;">
<li><a href="programmes.php#arts">Arts &amp; Culture</a></li>
<li><a href="programmes.php#promotions">Economic, Investment, Trade &amp; Tourism Promotions</a></li>
<li><a href="programmes.php#radio">Radio &amp; Television</a></li>
<li><a href="programmes.php#educational">Educational Support</a></li>
<li><a href="programmes.php#games">Afro-Caribbean Games Fiesta</a></li>
<li><a href="programmes.php#award">Royal Eagle Award</a></li>
<li><a href="programmes.php#seminar">Conference, Forum &amp; Seminar</a></li>
<li><a href="programmes.php#compendium">Compendium &amp; Profiles</a></li>
<li><a href="programmes.php#packaging">Exclusive Packaging &amp; Promotions</a></li>
</ul>
</td></tr></table>
 
 
 
 </td></tr></table> 
  
  
  
</p></td>
    <td width="267" valign="top"  style="font-family:corbel;font-size:14px;"><div align="right"><img src="images/facebooktwitter.png" alt="socialmedia" width="80" height="43" usemap="#Map" border="0"></div>
    <br>
    <table width="100%" cellpadding="3px" cellspacing="0px">
      <tr><td width="1%" style="background-color:#B22106;border-bottom:1px solid #B22106;"></td>
        <td style="background-color:#FFA477;color:white;border-bottom:1px solid #B22106;font-weight:bold;">AFRICEF Quick Links</td><tr><tr>
    <td colspan="2" style="font-size:13px;padding:5px;"><div align="left" style="color:#000000;padding:5px;">Objectives</div>
<div align="left" style="color:#000000;padding:5px;">Speakers & Panelists</div>
<div align="left" style="color:#000000;padding:5px;">Program of Events</div>
<div align="left" style="color:#000000;padding:5px;">Plenary Session</div>
<div align="left" style="color:#000000;padding:5px;">G2G, G2B & B2B Breakaway Networking Sessions </div>
<div align="left" style="color:#000000;padding:5px;">ACNF Patrons Inductees  </div>
<div align="left" style="color:#000000;padding:5px;">Investment Tours  </div>
<div align="left" style="color:#000000;padding:5px;">Exhibition   </div>
<div align="left" style="color:#000000;padding:5px;">Registration   </div>
<div align="left" style="color:#000000;padding:5px;">Sponsorship & Branding   </div>
    
  
</td></tr></table>
    
  <p><br>
    </p>
  <p><br>
  </p></td>
  </tr>
</table>


