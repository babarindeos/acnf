<script language="javascript">
<!--hide

function slide(){
 document.getElementById('slideimage').innerHTML="<img src='slideimages/bnr2.jpg'>";
  setTimeout("slide2()",5000);
 
}

function slide2(){
 document.getElementById('slideimage').innerHTML="<img src='slideimages/bnr3.jpg'>";
  setTimeout("slide3()",5000);

}

function slide3(){
 document.getElementById('slideimage').innerHTML="<img src='slideimages/bnr4.jpg'>";
  setTimeout("slide4()",5000);

}

function slide4(){
 document.getElementById('slideimage').innerHTML="<img src='slideimages/bnr5.jpg'>";
  setTimeout("slide5()",5000);

}

function slide5(){
 document.getElementById('slideimage').innerHTML="<img src='slideimages/bnr6.jpg'>";
  setTimeout("slide()",5000);

}



//-->
</script>

<table width="946px" style="padding-left:6px;padding-right:6px;" cellspacing="0px" border="0">
<tr>
<td>
<div id="slideimage"><img src="images/bnr2.jpg" />
</div>
</td>
</tr>
</table>
